class LabController < ApplicationController
  def index
  end
end
